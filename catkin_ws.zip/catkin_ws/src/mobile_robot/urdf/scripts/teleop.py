#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist

def teleop_control():
    rospy.init_node('teleop_control', anonymous=True)
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    rate = rospy.Rate(10)
    twist = Twist()

    while not rospy.is_shutdown():
        # Example: Set linear x and angular z velocities
        twist.linear.x = float(input("Enter linear velocity: "))
        twist.angular.z = float(input("Enter angular velocity: "))
        pub.publish(twist)
        rate.sleep()

if __name__ == '__main__':
    try:
        teleop_control()
    except rospy.ROSInterruptException:
        pass

