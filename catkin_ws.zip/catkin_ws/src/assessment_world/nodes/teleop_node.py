#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
import sys, select, termios, tty

# Display instructions
instructions = """
Control Your Robot!
---------------------------
Moving around:
   w
a  s  d
   x

w/x : increase/decrease linear speed
a/d : increase/decrease angular speed
space key : stop the robot

CTRL-C to quit
"""

move_bindings = {
    'w': (1, 0),
    'x': (-1, 0),
    'a': (0, 1),
    'd': (0, -1),
}

def get_key():
    """Read keypresses from the keyboard."""
    tty.setraw(sys.stdin.fileno())
    select.select([sys.stdin], [], [], 0)
    key = sys.stdin.read(1)
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

if __name__ == "__main__":
    settings = termios.tcgetattr(sys.stdin)

    rospy.init_node('teleop_twist_keyboard')
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

    speed = 0.5  # Linear speed
    turn = 1.0   # Angular speed
    twist = Twist()

    try:
        print(instructions)
        while not rospy.is_shutdown():
            key = get_key()
            if key in move_bindings.keys():
                twist.linear.x = move_bindings[key][0] * speed
                twist.angular.z = move_bindings[key][1] * turn
            elif key == ' ':
                twist.linear.x = 0.0
                twist.angular.z = 0.0
            elif key == '\x03':  # CTRL-C
                break

            pub.publish(twist)
    except Exception as e:
        print(e)
    finally:
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        pub.publish(twist)
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)

