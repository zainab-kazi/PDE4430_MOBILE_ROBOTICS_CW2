#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist

def move_robot():
    rospy.init_node('control_node', anonymous=True)
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    rate = rospy.Rate(10)  # 10 Hz
    move_cmd = Twist()
    move_cmd.linear.x = 0.5  # Forward velocity
    move_cmd.angular.z = 0.0  # No rotation

    while not rospy.is_shutdown():
        pub.publish(move_cmd)
        rate.sleep()

if __name__ == '__main__':
    try:
        move_robot()
    except rospy.ROSInterruptException:
        pass
