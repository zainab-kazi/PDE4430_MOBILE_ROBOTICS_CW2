#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
import sys, select, termios, tty

# Instructions for using the keyboard teleop
instructions = """
Control Your Robot!
---------------------------
Moving around:
   w
a  s  d
   x

w/x : increase/decrease linear speed
a/d : increase/decrease angular speed
space key : stop

CTRL-C to quit
"""

# Key bindings for movement
move_bindings = {
    'w': (1, 0),  # Move forward
    'x': (-1, 0), # Move backward
    'a': (0, 1),  # Turn left
    'd': (0, -1), # Turn right
}

def get_key():
    """Capture key presses from the keyboard."""
    tty.setraw(sys.stdin.fileno())
    select.select([sys.stdin], [], [], 0)
    key = sys.stdin.read(1)
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

if __name__ == "__main__":
    # Save the terminal settings
    settings = termios.tcgetattr(sys.stdin)

    # Initialize the ROS node
    rospy.init_node('teleop_twist_keyboard')
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

    # Define speed and turn rate
    speed = 0.5  # Linear speed
    turn = 1.0   # Angular speed

    # Display instructions
    print(instructions)

    try:
        while not rospy.is_shutdown():
            key = get_key()
            if key in move_bindings.keys():
                twist = Twist()
                twist.linear.x = move_bindings[key][0] * speed
                twist.angular.z = move_bindings[key][1] * turn
                pub.publish(twist)
            elif key == ' ':  # Stop
                twist = Twist()
                pub.publish(twist)
            elif key == '\x03':  # CTRL-C
                break
    except Exception as e:
        print(e)
    finally:
        # Restore terminal settings
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
